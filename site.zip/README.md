# EuroscolaRO2018 - Explore IT with Us

### How to test this project:

##### Windows
1. Download & install Linux;
2. Continue with the steps bellow.

Note: *I really don't know how to do this on Windows; I don't own a Windows machine now, so I have no way to test it. Sorry!*

##### MacOSX / Linux
  1. clone the project somewhere in your computer;
  2. open terminal and cd to the root of the project folder;
  3. run `php -S localhost:8000` ;
  4. go to your browser and type "localhost:8000" in the searching box.
  
##### or be lazy and just press the link from above